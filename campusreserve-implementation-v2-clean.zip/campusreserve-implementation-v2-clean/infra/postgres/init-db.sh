#!/bin/sh
set -e

for file in /bootstrap/migrations/*.sql; do
  echo "Applying migration: $file"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" -f "$file"
done

for file in /bootstrap/seeds/*.sql; do
  echo "Applying seed: $file"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" -f "$file"
done
