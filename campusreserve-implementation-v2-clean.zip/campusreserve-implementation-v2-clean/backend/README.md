# CampusReserve backend starter

Это минимальный каркас API для первого этапа проекта.

## Что есть внутри
- Gin router
- PostgreSQL подключение через GORM
- Repository слой
- Service слой с базовой бизнес-логикой бронирования
- Handlers для справочников, бронирований и админских действий
- Пример заглушки авторизации через `X-User-ID` и `X-User-Role`

## Быстрый запуск
1. Скопируй `.env.example` в `.env` или задай переменные окружения.
2. Подними PostgreSQL.
3. Примени миграции из `db/migrations`.
4. Запусти API:

```bash
cd backend
go run ./cmd/api
```

## Доступные маршруты
- `GET /health`
- `GET /buildings`
- `GET /buildings/:id/rooms`
- `GET /rooms/:id`
- `GET /rooms/:id/availability?from=...&to=...`
- `POST /bookings`
- `GET /bookings/:id`
- `GET /bookings/my`
- `PATCH /bookings/:id/cancel`
- `GET /admin/bookings?status=pending`
- `PATCH /admin/bookings/:id/approve`
- `PATCH /admin/bookings/:id/reject`
- `POST /admin/rooms/:id/unavailability`

## Временная аутентификация для локальной разработки
Пока нет полноценной auth-схемы, handlers читают пользователя из заголовков:
- `X-User-ID: 1`
- `X-User-Role: admin|teacher|student`
