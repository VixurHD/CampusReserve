package main

import (
	"log"

	"github.com/VixurHD/CampusReserve/backend/internal/config"
	"github.com/VixurHD/CampusReserve/backend/internal/database"
	transport "github.com/VixurHD/CampusReserve/backend/internal/http"
	"github.com/VixurHD/CampusReserve/backend/internal/http/handlers"
	"github.com/VixurHD/CampusReserve/backend/internal/repository"
	"github.com/VixurHD/CampusReserve/backend/internal/service"
)

func main() {
	cfg := config.Load()
	db, err := database.Connect(cfg)
	if err != nil {
		log.Fatalf("database connection failed: %v", err)
	}

	catalogRepo := repository.NewCatalogRepository(db)
	bookingRepo := repository.NewBookingRepository(db)

	catalogService := service.NewCatalogService(catalogRepo, bookingRepo)
	bookingService := service.NewBookingService(bookingRepo, catalogRepo)

	catalogHandler := handlers.NewCatalogHandler(catalogService)
	bookingHandler := handlers.NewBookingHandler(bookingService)

	router := transport.NewRouter(catalogHandler, bookingHandler)
	log.Printf("CampusReserve API listening on :%s", cfg.HTTPPort)
	if err := router.Run(":" + cfg.HTTPPort); err != nil {
		log.Fatalf("http server failed: %v", err)
	}
}
