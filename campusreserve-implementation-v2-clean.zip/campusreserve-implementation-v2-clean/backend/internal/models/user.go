package models

type User struct {
	ID           uint64   `gorm:"primaryKey;autoIncrement"`
	FullName     string   `gorm:"type:text;not null"`
	Email        string   `gorm:"type:text;not null;uniqueIndex"`
	PasswordHash *string  `gorm:"type:text"`
	Role         UserRole `gorm:"type:text;not null;index"`
	GroupName    *string  `gorm:"type:text"`
	Department   *string  `gorm:"type:text"`
	IsActive     bool     `gorm:"not null;default:true"`
	Timestamped
	SoftDeletable

	Bookings                []Booking              `gorm:"foreignKey:UserID"`
	ApprovedBookings        []Booking              `gorm:"foreignKey:ApprovedBy"`
	CreatedUnavailabilities []RoomUnavailability   `gorm:"foreignKey:CreatedBy"`
	BookingStatusChanges    []BookingStatusHistory `gorm:"foreignKey:ChangedBy"`
}
