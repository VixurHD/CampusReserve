package models

import "time"

type RoomUnavailability struct {
	ID        uint64               `gorm:"primaryKey;autoIncrement"`
	RoomID    uint64               `gorm:"not null;index"`
	StartsAt  time.Time            `gorm:"not null"`
	EndsAt    time.Time            `gorm:"not null"`
	Reason    string               `gorm:"type:text;not null"`
	Source    UnavailabilitySource `gorm:"type:text;not null"`
	CreatedBy *uint64              `gorm:"index"`
	CreatedAt time.Time            `gorm:"not null"`

	Room    Room  `gorm:"foreignKey:RoomID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;"`
	Creator *User `gorm:"foreignKey:CreatedBy;constraint:OnUpdate:CASCADE,OnDelete:SET NULL;"`
}

type Booking struct {
	ID              uint64        `gorm:"primaryKey;autoIncrement"`
	RoomID          uint64        `gorm:"not null;index"`
	UserID          uint64        `gorm:"not null;index"`
	Title           string        `gorm:"type:text;not null"`
	Description     *string       `gorm:"type:text"`
	StartsAt        time.Time     `gorm:"not null"`
	EndsAt          time.Time     `gorm:"not null"`
	AttendeesCount  *int          `gorm:"type:int"`
	Status          BookingStatus `gorm:"type:text;not null;index"`
	RejectionReason *string       `gorm:"type:text"`
	ApprovedBy      *uint64       `gorm:"index"`
	ApprovedAt      *time.Time
	Timestamped

	Room          Room                   `gorm:"foreignKey:RoomID;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;"`
	User          User                   `gorm:"foreignKey:UserID;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;"`
	Approver      *User                  `gorm:"foreignKey:ApprovedBy;constraint:OnUpdate:CASCADE,OnDelete:SET NULL;"`
	StatusHistory []BookingStatusHistory `gorm:"foreignKey:BookingID"`
}

type BookingStatusHistory struct {
	ID        uint64         `gorm:"primaryKey;autoIncrement"`
	BookingID uint64         `gorm:"not null;index"`
	OldStatus *BookingStatus `gorm:"type:text"`
	NewStatus BookingStatus  `gorm:"type:text;not null"`
	ChangedBy *uint64        `gorm:"index"`
	Comment   *string        `gorm:"type:text"`
	CreatedAt time.Time      `gorm:"not null"`

	Booking Booking `gorm:"foreignKey:BookingID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;"`
	Actor   *User   `gorm:"foreignKey:ChangedBy;constraint:OnUpdate:CASCADE,OnDelete:SET NULL;"`
}

func (b Booking) IsTerminal() bool {
	return b.Status == BookingStatusRejected ||
		b.Status == BookingStatusCancelled ||
		b.Status == BookingStatusCompleted
}
