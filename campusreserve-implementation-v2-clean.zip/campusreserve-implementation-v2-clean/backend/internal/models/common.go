package models

import (
	"time"

	"gorm.io/gorm"
)

type UserRole string

type RoomType string

type UnavailabilitySource string

type BookingStatus string

const (
	UserRoleStudent UserRole = "student"
	UserRoleTeacher UserRole = "teacher"
	UserRoleAdmin   UserRole = "admin"
)

const (
	RoomTypeLecture   RoomType = "lecture"
	RoomTypePractice  RoomType = "practice"
	RoomTypeLab       RoomType = "lab"
	RoomTypeCoworking RoomType = "coworking"
	RoomTypeMeeting   RoomType = "meeting"
)

const (
	UnavailabilitySourceManual         UnavailabilitySource = "manual"
	UnavailabilitySourceScheduleImport UnavailabilitySource = "schedule_import"
	UnavailabilitySourceMaintenance    UnavailabilitySource = "maintenance"
)

const (
	BookingStatusPending   BookingStatus = "pending"
	BookingStatusApproved  BookingStatus = "approved"
	BookingStatusRejected  BookingStatus = "rejected"
	BookingStatusCancelled BookingStatus = "cancelled"
	BookingStatusCompleted BookingStatus = "completed"
)

type Timestamped struct {
	CreatedAt time.Time `gorm:"not null"`
	UpdatedAt time.Time `gorm:"not null"`
}

type SoftDeletable struct {
	DeletedAt gorm.DeletedAt `gorm:"index"`
}
