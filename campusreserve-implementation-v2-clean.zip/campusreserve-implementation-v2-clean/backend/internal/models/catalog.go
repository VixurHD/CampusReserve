package models

import "time"

type Building struct {
	ID          uint64  `gorm:"primaryKey;autoIncrement"`
	Code        string  `gorm:"type:text;not null;uniqueIndex"`
	Name        string  `gorm:"type:text;not null"`
	Address     *string `gorm:"type:text"`
	Description *string `gorm:"type:text"`
	Timestamped

	Rooms []Room `gorm:"foreignKey:BuildingID"`
}

type Room struct {
	ID          uint64   `gorm:"primaryKey;autoIncrement"`
	BuildingID  uint64   `gorm:"not null;index;uniqueIndex:ux_room_building_number"`
	RoomNumber  string   `gorm:"type:text;not null;uniqueIndex:ux_room_building_number"`
	Name        *string  `gorm:"type:text"`
	Floor       *int     `gorm:"type:int"`
	Capacity    int      `gorm:"not null;default:0"`
	RoomType    RoomType `gorm:"type:text;not null;index"`
	Description *string  `gorm:"type:text"`
	IsActive    bool     `gorm:"not null;default:true;index"`
	Timestamped

	Building         Building             `gorm:"foreignKey:BuildingID;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;"`
	EquipmentLinks   []RoomEquipment      `gorm:"foreignKey:RoomID"`
	Unavailabilities []RoomUnavailability `gorm:"foreignKey:RoomID"`
	Bookings         []Booking            `gorm:"foreignKey:RoomID"`
}

type Equipment struct {
	ID          uint64  `gorm:"primaryKey;autoIncrement"`
	Code        string  `gorm:"type:text;not null;uniqueIndex"`
	Name        string  `gorm:"type:text;not null"`
	Description *string `gorm:"type:text"`
	Timestamped

	RoomLinks []RoomEquipment `gorm:"foreignKey:EquipmentID"`
}

type RoomEquipment struct {
	RoomID      uint64    `gorm:"primaryKey"`
	EquipmentID uint64    `gorm:"primaryKey"`
	Quantity    int       `gorm:"not null;default:1"`
	CreatedAt   time.Time `gorm:"not null"`

	Room      Room      `gorm:"foreignKey:RoomID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;"`
	Equipment Equipment `gorm:"foreignKey:EquipmentID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;"`
}

func (RoomEquipment) TableName() string {
	return "room_equipment"
}
