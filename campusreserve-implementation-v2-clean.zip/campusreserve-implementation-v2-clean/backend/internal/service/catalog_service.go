package service

import (
	"context"
	"errors"
	"time"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/VixurHD/CampusReserve/backend/internal/dto"
	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"github.com/VixurHD/CampusReserve/backend/internal/repository"
	"gorm.io/gorm"
)

type CatalogService struct {
	catalogRepo *repository.CatalogRepository
	bookingRepo *repository.BookingRepository
}

func NewCatalogService(catalogRepo *repository.CatalogRepository, bookingRepo *repository.BookingRepository) *CatalogService {
	return &CatalogService{catalogRepo: catalogRepo, bookingRepo: bookingRepo}
}

func (s *CatalogService) ListBuildings(ctx context.Context) ([]models.Building, error) {
	items, err := s.catalogRepo.ListBuildings(ctx)
	if err != nil {
		return nil, app.InternalError("не удалось получить список корпусов", err)
	}
	return items, nil
}

func (s *CatalogService) ListRoomsByBuilding(ctx context.Context, buildingID uint64) ([]models.Room, error) {
	items, err := s.catalogRepo.ListRoomsByBuilding(ctx, buildingID)
	if err != nil {
		return nil, app.InternalError("не удалось получить список аудиторий", err)
	}
	return items, nil
}

func (s *CatalogService) GetRoom(ctx context.Context, roomID uint64) (*models.Room, error) {
	item, err := s.catalogRepo.GetRoomByID(ctx, roomID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, app.NotFoundError("аудитория не найдена")
		}
		return nil, app.InternalError("не удалось получить аудиторию", err)
	}
	return item, nil
}

func (s *CatalogService) CheckAvailability(ctx context.Context, roomID uint64, startsAt, endsAt time.Time) (*dto.AvailabilityResponse, error) {
	if !startsAt.Before(endsAt) {
		return nil, app.ValidationError("время начала должно быть раньше времени окончания")
	}

	room, err := s.GetRoom(ctx, roomID)
	if err != nil {
		return nil, err
	}
	if !room.IsActive {
		return &dto.AvailabilityResponse{RoomID: roomID, Available: false, ConflictsWith: "room_inactive"}, nil
	}

	blocked, err := s.catalogRepo.HasUnavailabilityConflict(ctx, roomID, startsAt, endsAt)
	if err != nil {
		return nil, app.InternalError("не удалось проверить блокировки аудитории", err)
	}
	if blocked {
		return &dto.AvailabilityResponse{RoomID: roomID, Available: false, ConflictsWith: "room_unavailability"}, nil
	}

	busy, err := s.bookingRepo.HasApprovedConflict(ctx, s.bookingRepo.RawDB(), roomID, startsAt, endsAt, nil)
	if err != nil {
		return nil, app.InternalError("не удалось проверить подтверждённые бронирования", err)
	}
	if busy {
		return &dto.AvailabilityResponse{RoomID: roomID, Available: false, ConflictsWith: "approved_booking"}, nil
	}

	return &dto.AvailabilityResponse{RoomID: roomID, Available: true}, nil
}
