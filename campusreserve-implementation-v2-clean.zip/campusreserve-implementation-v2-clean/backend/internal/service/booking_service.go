package service

import (
	"context"
	"errors"
	"strings"
	"time"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/VixurHD/CampusReserve/backend/internal/dto"
	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"github.com/VixurHD/CampusReserve/backend/internal/repository"
	"gorm.io/gorm"
)

type BookingService struct {
	bookingRepo *repository.BookingRepository
	catalogRepo *repository.CatalogRepository
}

func NewBookingService(bookingRepo *repository.BookingRepository, catalogRepo *repository.CatalogRepository) *BookingService {
	return &BookingService{bookingRepo: bookingRepo, catalogRepo: catalogRepo}
}

func (s *BookingService) CreateBooking(ctx context.Context, actorID uint64, req dto.CreateBookingRequest) (*models.Booking, error) {
	startsAt, endsAt, err := parseDateRange(req.StartsAt, req.EndsAt)
	if err != nil {
		return nil, err
	}
	if startsAt.Before(time.Now().UTC()) {
		return nil, app.ValidationError("нельзя создать бронирование в прошлом")
	}

	room, err := s.catalogRepo.GetRoomByID(ctx, req.RoomID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, app.NotFoundError("аудитория не найдена")
		}
		return nil, app.InternalError("не удалось загрузить аудиторию", err)
	}
	if !room.IsActive {
		return nil, app.ConflictError("аудитория неактивна и недоступна для бронирования")
	}
	if req.AttendeesCount != nil && *req.AttendeesCount > room.Capacity {
		return nil, app.ValidationError("ожидаемое число участников превышает вместимость аудитории")
	}

	booking := &models.Booking{
		RoomID:         req.RoomID,
		UserID:         actorID,
		Title:          strings.TrimSpace(req.Title),
		Description:    optionalTrimmedPtr(req.Description),
		StartsAt:       startsAt,
		EndsAt:         endsAt,
		AttendeesCount: req.AttendeesCount,
		Status:         models.BookingStatusPending,
	}

	err = s.bookingRepo.WithTransaction(ctx, func(tx *gorm.DB) error {
		busy, err := s.bookingRepo.HasApprovedConflict(ctx, tx, req.RoomID, startsAt, endsAt, nil)
		if err != nil {
			return app.InternalError("не удалось проверить пересечения с подтверждёнными бронированиями", err)
		}
		if busy {
			return app.ConflictError("на это время уже есть подтверждённое бронирование")
		}

		blocked, err := s.bookingRepo.HasUnavailabilityConflict(ctx, tx, req.RoomID, startsAt, endsAt)
		if err != nil {
			return app.InternalError("не удалось проверить недоступность аудитории", err)
		}
		if blocked {
			return app.ConflictError("аудитория недоступна в выбранный интервал")
		}

		if err := tx.WithContext(ctx).Create(booking).Error; err != nil {
			return app.InternalError("не удалось создать бронирование", err)
		}

		history := &models.BookingStatusHistory{
			BookingID: booking.ID,
			NewStatus: models.BookingStatusPending,
			ChangedBy: &actorID,
			Comment:   stringPtr("booking created"),
		}
		if err := tx.WithContext(ctx).Create(history).Error; err != nil {
			return app.InternalError("не удалось сохранить историю статусов", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}

	return s.GetBooking(ctx, booking.ID)
}

func (s *BookingService) GetBooking(ctx context.Context, bookingID uint64) (*models.Booking, error) {
	booking, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, app.NotFoundError("бронирование не найдено")
		}
		return nil, app.InternalError("не удалось получить бронирование", err)
	}
	return booking, nil
}

func (s *BookingService) ListMyBookings(ctx context.Context, userID uint64) ([]models.Booking, error) {
	items, err := s.bookingRepo.ListByUser(ctx, userID)
	if err != nil {
		return nil, app.InternalError("не удалось получить список бронирований пользователя", err)
	}
	return items, nil
}

func (s *BookingService) ListAdminBookings(ctx context.Context, actorRole models.UserRole, status models.BookingStatus) ([]models.Booking, error) {
	if actorRole != models.UserRoleAdmin {
		return nil, app.ForbiddenError("только администратор может смотреть административный список бронирований")
	}
	if status != "" && !isValidBookingStatus(status) {
		return nil, app.ValidationError("status должен быть одним из: pending, approved, rejected, cancelled, completed")
	}
	items, err := s.bookingRepo.ListByStatus(ctx, status)
	if err != nil {
		return nil, app.InternalError("не удалось получить список бронирований", err)
	}
	return items, nil
}

func (s *BookingService) CancelBooking(ctx context.Context, actorID uint64, actorRole models.UserRole, bookingID uint64) (*models.Booking, error) {
	err := s.bookingRepo.WithTransaction(ctx, func(tx *gorm.DB) error {
		booking, err := s.bookingRepo.GetByIDForUpdate(ctx, tx, bookingID)
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return app.NotFoundError("бронирование не найдено")
			}
			return app.InternalError("не удалось получить бронирование", err)
		}
		if booking.UserID != actorID && actorRole != models.UserRoleAdmin {
			return app.ForbiddenError("отменить бронирование может только создатель или администратор")
		}
		if booking.Status == models.BookingStatusCancelled {
			return app.ConflictError("бронирование уже отменено")
		}
		if booking.IsTerminal() && booking.Status != models.BookingStatusApproved {
			return app.ConflictError("нельзя отменить бронирование в терминальном статусе")
		}

		oldStatus := booking.Status
		booking.Status = models.BookingStatusCancelled
		booking.RejectionReason = nil
		booking.ApprovedAt = nil
		booking.ApprovedBy = nil

		if err := s.bookingRepo.Save(ctx, tx, booking); err != nil {
			return app.InternalError("не удалось отменить бронирование", err)
		}

		history := &models.BookingStatusHistory{
			BookingID: booking.ID,
			OldStatus: &oldStatus,
			NewStatus: models.BookingStatusCancelled,
			ChangedBy: &actorID,
			Comment:   stringPtr("booking cancelled"),
		}
		if err := tx.WithContext(ctx).Create(history).Error; err != nil {
			return app.InternalError("не удалось сохранить историю статусов", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return s.GetBooking(ctx, bookingID)
}

func (s *BookingService) ApproveBooking(ctx context.Context, actorID uint64, actorRole models.UserRole, bookingID uint64, comment string) (*models.Booking, error) {
	if actorRole != models.UserRoleAdmin {
		return nil, app.ForbiddenError("подтверждать бронирования может только администратор")
	}

	err := s.bookingRepo.WithTransaction(ctx, func(tx *gorm.DB) error {
		booking, err := s.bookingRepo.GetByIDForUpdate(ctx, tx, bookingID)
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return app.NotFoundError("бронирование не найдено")
			}
			return app.InternalError("не удалось получить бронирование", err)
		}
		if booking.Status != models.BookingStatusPending {
			return app.ConflictError("подтверждать можно только заявки в статусе pending")
		}

		room, err := s.catalogRepo.GetRoomByID(ctx, booking.RoomID)
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return app.NotFoundError("аудитория не найдена")
			}
			return app.InternalError("не удалось получить аудиторию", err)
		}
		if !room.IsActive {
			return app.ConflictError("нельзя подтвердить бронь для неактивной аудитории")
		}

		busy, err := s.bookingRepo.HasApprovedConflict(ctx, tx, booking.RoomID, booking.StartsAt, booking.EndsAt, &booking.ID)
		if err != nil {
			return app.InternalError("не удалось проверить пересечения с другими подтверждёнными бронированиями", err)
		}
		if busy {
			return app.ConflictError("есть пересечение с другим подтверждённым бронированием")
		}

		blocked, err := s.bookingRepo.HasUnavailabilityConflict(ctx, tx, booking.RoomID, booking.StartsAt, booking.EndsAt)
		if err != nil {
			return app.InternalError("не удалось проверить блокировки аудитории", err)
		}
		if blocked {
			return app.ConflictError("аудитория недоступна в этот интервал")
		}

		now := time.Now().UTC()
		oldStatus := booking.Status
		booking.Status = models.BookingStatusApproved
		booking.ApprovedAt = &now
		booking.ApprovedBy = &actorID
		booking.RejectionReason = nil

		if err := s.bookingRepo.Save(ctx, tx, booking); err != nil {
			return app.InternalError("не удалось подтвердить бронирование", err)
		}

		history := &models.BookingStatusHistory{
			BookingID: booking.ID,
			OldStatus: &oldStatus,
			NewStatus: models.BookingStatusApproved,
			ChangedBy: &actorID,
			Comment:   optionalTrimmed(comment),
		}
		if history.Comment == nil {
			history.Comment = stringPtr("booking approved")
		}
		if err := tx.WithContext(ctx).Create(history).Error; err != nil {
			return app.InternalError("не удалось сохранить историю статусов", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return s.GetBooking(ctx, bookingID)
}

func (s *BookingService) RejectBooking(ctx context.Context, actorID uint64, actorRole models.UserRole, bookingID uint64, reason string) (*models.Booking, error) {
	if actorRole != models.UserRoleAdmin {
		return nil, app.ForbiddenError("отклонять бронирования может только администратор")
	}
	if strings.TrimSpace(reason) == "" {
		return nil, app.ValidationError("нужно указать причину отклонения")
	}

	err := s.bookingRepo.WithTransaction(ctx, func(tx *gorm.DB) error {
		booking, err := s.bookingRepo.GetByIDForUpdate(ctx, tx, bookingID)
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return app.NotFoundError("бронирование не найдено")
			}
			return app.InternalError("не удалось получить бронирование", err)
		}
		if booking.Status != models.BookingStatusPending {
			return app.ConflictError("отклонять можно только заявки в статусе pending")
		}

		oldStatus := booking.Status
		booking.Status = models.BookingStatusRejected
		booking.RejectionReason = stringPtr(strings.TrimSpace(reason))
		booking.ApprovedAt = nil
		booking.ApprovedBy = nil

		if err := s.bookingRepo.Save(ctx, tx, booking); err != nil {
			return app.InternalError("не удалось отклонить бронирование", err)
		}

		history := &models.BookingStatusHistory{
			BookingID: booking.ID,
			OldStatus: &oldStatus,
			NewStatus: models.BookingStatusRejected,
			ChangedBy: &actorID,
			Comment:   stringPtr(strings.TrimSpace(reason)),
		}
		if err := tx.WithContext(ctx).Create(history).Error; err != nil {
			return app.InternalError("не удалось сохранить историю статусов", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return s.GetBooking(ctx, bookingID)
}

func (s *BookingService) CreateUnavailability(ctx context.Context, actorID uint64, actorRole models.UserRole, roomID uint64, req dto.CreateUnavailabilityRequest) (*models.RoomUnavailability, error) {
	if actorRole != models.UserRoleAdmin {
		return nil, app.ForbiddenError("создавать блокировки может только администратор")
	}
	startsAt, endsAt, err := parseDateRange(req.StartsAt, req.EndsAt)
	if err != nil {
		return nil, err
	}

	room, err := s.catalogRepo.GetRoomByID(ctx, roomID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, app.NotFoundError("аудитория не найдена")
		}
		return nil, app.InternalError("не удалось получить аудиторию", err)
	}
	if !room.IsActive {
		return nil, app.ConflictError("нельзя блокировать неактивную аудиторию")
	}

	source := models.UnavailabilitySourceManual
	if trimmed := strings.TrimSpace(req.Source); trimmed != "" {
		source = models.UnavailabilitySource(trimmed)
	}
	if source != models.UnavailabilitySourceManual && source != models.UnavailabilitySourceMaintenance && source != models.UnavailabilitySourceScheduleImport {
		return nil, app.ValidationError("source должен быть одним из: manual, maintenance, schedule_import")
	}

	entry := &models.RoomUnavailability{
		RoomID:    roomID,
		StartsAt:  startsAt,
		EndsAt:    endsAt,
		Reason:    strings.TrimSpace(req.Reason),
		Source:    source,
		CreatedBy: &actorID,
	}

	err = s.bookingRepo.WithTransaction(ctx, func(tx *gorm.DB) error {
		busy, err := s.bookingRepo.HasApprovedConflict(ctx, tx, roomID, startsAt, endsAt, nil)
		if err != nil {
			return app.InternalError("не удалось проверить пересечение с подтверждёнными бронированиями", err)
		}
		if busy {
			return app.ConflictError("нельзя создать блокировку поверх подтверждённого бронирования")
		}

		blocked, err := s.bookingRepo.HasUnavailabilityConflict(ctx, tx, roomID, startsAt, endsAt)
		if err != nil {
			return app.InternalError("не удалось проверить существующие блокировки", err)
		}
		if blocked {
			return app.ConflictError("у аудитории уже есть блокировка на этот интервал")
		}

		if err := tx.WithContext(ctx).Create(entry).Error; err != nil {
			return app.InternalError("не удалось создать блокировку аудитории", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}

	return entry, nil
}

func parseDateRange(startsAtRaw, endsAtRaw string) (time.Time, time.Time, error) {
	startsAt, err := time.Parse(time.RFC3339, strings.TrimSpace(startsAtRaw))
	if err != nil {
		return time.Time{}, time.Time{}, app.ValidationError("starts_at должен быть в формате RFC3339")
	}
	endsAt, err := time.Parse(time.RFC3339, strings.TrimSpace(endsAtRaw))
	if err != nil {
		return time.Time{}, time.Time{}, app.ValidationError("ends_at должен быть в формате RFC3339")
	}
	startsAt = startsAt.UTC()
	endsAt = endsAt.UTC()
	if !startsAt.Before(endsAt) {
		return time.Time{}, time.Time{}, app.ValidationError("время начала должно быть раньше времени окончания")
	}
	return startsAt, endsAt, nil
}

func optionalTrimmed(value string) *string {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return nil
	}
	return &trimmed
}

func optionalTrimmedPtr(value *string) *string {
	if value == nil {
		return nil
	}
	return optionalTrimmed(*value)
}

func stringPtr(value string) *string {
	v := value
	return &v
}

func isValidBookingStatus(status models.BookingStatus) bool {
	switch status {
	case models.BookingStatusPending, models.BookingStatusApproved, models.BookingStatusRejected, models.BookingStatusCancelled, models.BookingStatusCompleted:
		return true
	default:
		return false
	}
}
