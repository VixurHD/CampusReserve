package middleware

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"github.com/gin-gonic/gin"
)

const (
	contextUserIDKey   = "user_id"
	contextUserRoleKey = "user_role"
)

func AuthContext() gin.HandlerFunc {
	return func(c *gin.Context) {
		userIDHeader := strings.TrimSpace(c.GetHeader("X-User-ID"))
		userRoleHeader := strings.TrimSpace(c.GetHeader("X-User-Role"))

		if userIDHeader != "" {
			userID, err := strconv.ParseUint(userIDHeader, 10, 64)
			if err != nil {
				c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": gin.H{"code": "validation_error", "message": "header X-User-ID должен быть положительным числом"}})
				return
			}
			c.Set(contextUserIDKey, userID)
		}

		if userRoleHeader != "" {
			c.Set(contextUserRoleKey, models.UserRole(strings.ToLower(userRoleHeader)))
		}

		c.Next()
	}
}

func RequireUser(c *gin.Context) (uint64, models.UserRole, error) {
	userIDValue, ok := c.Get(contextUserIDKey)
	if !ok {
		return 0, "", app.UnauthorizedError("для этого метода нужен header X-User-ID")
	}
	roleValue, ok := c.Get(contextUserRoleKey)
	if !ok {
		return 0, "", app.UnauthorizedError("для этого метода нужен header X-User-Role")
	}
	userID, ok := userIDValue.(uint64)
	if !ok {
		return 0, "", app.InternalError("не удалось получить пользователя из контекста", nil)
	}
	role, ok := roleValue.(models.UserRole)
	if !ok {
		return 0, "", app.InternalError("не удалось получить роль пользователя из контекста", nil)
	}
	return userID, role, nil
}
