package http

import (
	"net/http"

	"github.com/VixurHD/CampusReserve/backend/internal/http/handlers"
	"github.com/VixurHD/CampusReserve/backend/internal/http/middleware"
	"github.com/gin-gonic/gin"
)

func NewRouter(catalogHandler *handlers.CatalogHandler, bookingHandler *handlers.BookingHandler) *gin.Engine {
	router := gin.Default()
	router.Use(middleware.AuthContext())

	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	router.GET("/buildings", catalogHandler.ListBuildings)
	router.GET("/buildings/:id/rooms", catalogHandler.ListRoomsByBuilding)
	router.GET("/rooms/:id", catalogHandler.GetRoom)
	router.GET("/rooms/:id/availability", catalogHandler.CheckAvailability)

	router.POST("/bookings", bookingHandler.CreateBooking)
	router.GET("/bookings/:id", bookingHandler.GetBooking)
	router.GET("/bookings/my", bookingHandler.ListMyBookings)
	router.PATCH("/bookings/:id/cancel", bookingHandler.CancelBooking)

	admin := router.Group("/admin")
	{
		admin.GET("/bookings", bookingHandler.ListAdminBookings)
		admin.PATCH("/bookings/:id/approve", bookingHandler.ApproveBooking)
		admin.PATCH("/bookings/:id/reject", bookingHandler.RejectBooking)
		admin.POST("/rooms/:id/unavailability", bookingHandler.CreateUnavailability)
	}

	return router
}
