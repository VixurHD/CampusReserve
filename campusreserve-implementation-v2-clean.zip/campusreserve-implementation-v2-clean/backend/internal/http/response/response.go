package response

import (
	"net/http"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/gin-gonic/gin"
)

func JSON(c *gin.Context, status int, payload any) {
	c.JSON(status, payload)
}

func Error(c *gin.Context, err error) {
	if err == nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": gin.H{"code": app.CodeInternal, "message": "unknown error"}})
		return
	}

	if appErr, ok := err.(*app.AppError); ok {
		status := http.StatusInternalServerError
		switch appErr.Code {
		case app.CodeValidation:
			status = http.StatusBadRequest
		case app.CodeUnauthorized:
			status = http.StatusUnauthorized
		case app.CodeForbidden:
			status = http.StatusForbidden
		case app.CodeNotFound:
			status = http.StatusNotFound
		case app.CodeConflict:
			status = http.StatusConflict
		}

		c.JSON(status, gin.H{"error": gin.H{"code": appErr.Code, "message": appErr.Message}})
		return
	}

	c.JSON(http.StatusInternalServerError, gin.H{"error": gin.H{"code": app.CodeInternal, "message": err.Error()}})
}
