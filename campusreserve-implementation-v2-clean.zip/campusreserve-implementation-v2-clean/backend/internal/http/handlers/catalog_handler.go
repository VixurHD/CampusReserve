package handlers

import (
	"net/http"
	"strconv"
	"time"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/VixurHD/CampusReserve/backend/internal/http/response"
	"github.com/VixurHD/CampusReserve/backend/internal/service"
	"github.com/gin-gonic/gin"
)

type CatalogHandler struct {
	catalogService *service.CatalogService
}

func NewCatalogHandler(catalogService *service.CatalogService) *CatalogHandler {
	return &CatalogHandler{catalogService: catalogService}
}

func (h *CatalogHandler) ListBuildings(c *gin.Context) {
	items, err := h.catalogService.ListBuildings(c.Request.Context())
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": items})
}

func (h *CatalogHandler) ListRoomsByBuilding(c *gin.Context) {
	buildingID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id корпуса должен быть числом"))
		return
	}
	items, err := h.catalogService.ListRoomsByBuilding(c.Request.Context(), buildingID)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": items})
}

func (h *CatalogHandler) GetRoom(c *gin.Context) {
	roomID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id аудитории должен быть числом"))
		return
	}
	item, err := h.catalogService.GetRoom(c.Request.Context(), roomID)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": item})
}

func (h *CatalogHandler) CheckAvailability(c *gin.Context) {
	roomID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id аудитории должен быть числом"))
		return
	}
	startsAt, err := time.Parse(time.RFC3339, c.Query("from"))
	if err != nil {
		response.Error(c, app.ValidationError("параметр from должен быть в формате RFC3339"))
		return
	}
	endsAt, err := time.Parse(time.RFC3339, c.Query("to"))
	if err != nil {
		response.Error(c, app.ValidationError("параметр to должен быть в формате RFC3339"))
		return
	}
	item, err := h.catalogService.CheckAvailability(c.Request.Context(), roomID, startsAt.UTC(), endsAt.UTC())
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": item})
}
