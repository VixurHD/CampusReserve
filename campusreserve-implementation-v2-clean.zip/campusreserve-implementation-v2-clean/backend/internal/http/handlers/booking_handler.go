package handlers

import (
	"net/http"
	"strconv"

	"github.com/VixurHD/CampusReserve/backend/internal/app"
	"github.com/VixurHD/CampusReserve/backend/internal/dto"
	"github.com/VixurHD/CampusReserve/backend/internal/http/middleware"
	"github.com/VixurHD/CampusReserve/backend/internal/http/response"
	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"github.com/VixurHD/CampusReserve/backend/internal/service"
	"github.com/gin-gonic/gin"
)

type BookingHandler struct {
	bookingService *service.BookingService
}

func NewBookingHandler(bookingService *service.BookingService) *BookingHandler {
	return &BookingHandler{bookingService: bookingService}
}

func (h *BookingHandler) CreateBooking(c *gin.Context) {
	userID, _, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	var req dto.CreateBookingRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, app.ValidationError(err.Error()))
		return
	}
	booking, err := h.bookingService.CreateBooking(c.Request.Context(), userID, req)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusCreated, gin.H{"data": booking})
}

func (h *BookingHandler) GetBooking(c *gin.Context) {
	bookingID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id бронирования должен быть числом"))
		return
	}
	booking, err := h.bookingService.GetBooking(c.Request.Context(), bookingID)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": booking})
}

func (h *BookingHandler) ListMyBookings(c *gin.Context) {
	userID, _, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	items, err := h.bookingService.ListMyBookings(c.Request.Context(), userID)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": items})
}

func (h *BookingHandler) CancelBooking(c *gin.Context) {
	userID, role, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	bookingID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id бронирования должен быть числом"))
		return
	}
	booking, err := h.bookingService.CancelBooking(c.Request.Context(), userID, role, bookingID)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": booking})
}

func (h *BookingHandler) ListAdminBookings(c *gin.Context) {
	_, role, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	status := models.BookingStatus(c.Query("status"))
	items, err := h.bookingService.ListAdminBookings(c.Request.Context(), role, status)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": items})
}

func (h *BookingHandler) ApproveBooking(c *gin.Context) {
	userID, role, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	bookingID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id бронирования должен быть числом"))
		return
	}
	var req dto.UpdateBookingStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil && err.Error() != "EOF" {
		response.Error(c, app.ValidationError(err.Error()))
		return
	}
	booking, err := h.bookingService.ApproveBooking(c.Request.Context(), userID, role, bookingID, req.Comment)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": booking})
}

func (h *BookingHandler) RejectBooking(c *gin.Context) {
	userID, role, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	bookingID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id бронирования должен быть числом"))
		return
	}
	var req dto.RejectBookingRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, app.ValidationError(err.Error()))
		return
	}
	booking, err := h.bookingService.RejectBooking(c.Request.Context(), userID, role, bookingID, req.Reason)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusOK, gin.H{"data": booking})
}

func (h *BookingHandler) CreateUnavailability(c *gin.Context) {
	userID, role, err := middleware.RequireUser(c)
	if err != nil {
		response.Error(c, app.UnauthorizedError("для этого метода нужны заголовки X-User-ID и X-User-Role"))
		return
	}
	roomID, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		response.Error(c, app.ValidationError("id аудитории должен быть числом"))
		return
	}
	var req dto.CreateUnavailabilityRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, app.ValidationError(err.Error()))
		return
	}
	item, err := h.bookingService.CreateUnavailability(c.Request.Context(), userID, role, roomID, req)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.JSON(c, http.StatusCreated, gin.H{"data": item})
}
