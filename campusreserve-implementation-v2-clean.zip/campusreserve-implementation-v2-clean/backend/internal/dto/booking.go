package dto

type CreateBookingRequest struct {
	RoomID         uint64  `json:"room_id" binding:"required"`
	Title          string  `json:"title" binding:"required,min=3,max=255"`
	Description    *string `json:"description,omitempty"`
	StartsAt       string  `json:"starts_at" binding:"required"`
	EndsAt         string  `json:"ends_at" binding:"required"`
	AttendeesCount *int    `json:"attendees_count,omitempty"`
}

type UpdateBookingStatusRequest struct {
	Comment string `json:"comment,omitempty"`
}

type RejectBookingRequest struct {
	Reason string `json:"reason" binding:"required,min=3,max=1000"`
}

type CreateUnavailabilityRequest struct {
	StartsAt string `json:"starts_at" binding:"required"`
	EndsAt   string `json:"ends_at" binding:"required"`
	Reason   string `json:"reason" binding:"required,min=3,max=1000"`
	Source   string `json:"source,omitempty"`
}
