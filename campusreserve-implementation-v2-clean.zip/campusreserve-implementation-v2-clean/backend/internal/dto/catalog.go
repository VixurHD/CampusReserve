package dto

type AvailabilityResponse struct {
	RoomID        uint64 `json:"room_id"`
	Available     bool   `json:"available"`
	ConflictsWith string `json:"conflicts_with,omitempty"`
}
