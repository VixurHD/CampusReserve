package config

import (
	"fmt"
	"os"
)

type Config struct {
	AppEnv     string
	HTTPPort   string
	DBHost     string
	DBPort     string
	DBUser     string
	DBPassword string
	DBName     string
	DBSSLMode  string
}

func Load() Config {
	cfg := Config{
		AppEnv:     getenv("APP_ENV", "development"),
		HTTPPort:   getenv("HTTP_PORT", "8080"),
		DBHost:     getenv("DB_HOST", "localhost"),
		DBPort:     getenv("DB_PORT", "5432"),
		DBUser:     getenv("DB_USER", "campusreserve"),
		DBPassword: getenv("DB_PASSWORD", "campusreserve"),
		DBName:     getenv("DB_NAME", "campusreserve"),
		DBSSLMode:  getenv("DB_SSLMODE", "disable"),
	}
	return cfg
}

func (c Config) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s TimeZone=UTC",
		c.DBHost,
		c.DBPort,
		c.DBUser,
		c.DBPassword,
		c.DBName,
		c.DBSSLMode,
	)
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
