package app

import "fmt"

type ErrorCode string

const (
	CodeValidation   ErrorCode = "validation_error"
	CodeNotFound     ErrorCode = "not_found"
	CodeConflict     ErrorCode = "conflict"
	CodeForbidden    ErrorCode = "forbidden"
	CodeUnauthorized ErrorCode = "unauthorized"
	CodeInternal     ErrorCode = "internal_error"
)

type AppError struct {
	Code    ErrorCode `json:"code"`
	Message string    `json:"message"`
	Err     error     `json:"-"`
}

func (e *AppError) Error() string {
	if e.Err == nil {
		return fmt.Sprintf("%s: %s", e.Code, e.Message)
	}
	return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
}

func (e *AppError) Unwrap() error { return e.Err }

func NewError(code ErrorCode, message string, err error) *AppError {
	return &AppError{Code: code, Message: message, Err: err}
}

func ValidationError(message string) *AppError { return NewError(CodeValidation, message, nil) }
func NotFoundError(message string) *AppError   { return NewError(CodeNotFound, message, nil) }
func ConflictError(message string) *AppError   { return NewError(CodeConflict, message, nil) }
func ForbiddenError(message string) *AppError  { return NewError(CodeForbidden, message, nil) }
func UnauthorizedError(message string) *AppError {
	return NewError(CodeUnauthorized, message, nil)
}
func InternalError(message string, err error) *AppError {
	return NewError(CodeInternal, message, err)
}
