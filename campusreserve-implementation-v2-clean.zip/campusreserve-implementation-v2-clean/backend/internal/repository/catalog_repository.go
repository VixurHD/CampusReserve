package repository

import (
	"context"
	"time"

	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"gorm.io/gorm"
)

type CatalogRepository struct {
	db *gorm.DB
}

func NewCatalogRepository(db *gorm.DB) *CatalogRepository {
	return &CatalogRepository{db: db}
}

func (r *CatalogRepository) ListBuildings(ctx context.Context) ([]models.Building, error) {
	var buildings []models.Building
	err := r.db.WithContext(ctx).Order("name ASC").Find(&buildings).Error
	return buildings, err
}

func (r *CatalogRepository) ListRoomsByBuilding(ctx context.Context, buildingID uint64) ([]models.Room, error) {
	var rooms []models.Room
	err := r.db.WithContext(ctx).
		Preload("EquipmentLinks.Equipment").
		Where("building_id = ?", buildingID).
		Order("room_number ASC").
		Find(&rooms).Error
	return rooms, err
}

func (r *CatalogRepository) GetRoomByID(ctx context.Context, roomID uint64) (*models.Room, error) {
	var room models.Room
	err := r.db.WithContext(ctx).
		Preload("Building").
		Preload("EquipmentLinks.Equipment").
		First(&room, roomID).Error
	if err != nil {
		return nil, err
	}
	return &room, nil
}

func (r *CatalogRepository) HasUnavailabilityConflict(ctx context.Context, roomID uint64, startsAt, endsAt time.Time) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&models.RoomUnavailability{}).
		Where("room_id = ? AND starts_at < ? AND ends_at > ?", roomID, endsAt, startsAt).
		Count(&count).Error
	return count > 0, err
}

func (r *CatalogRepository) CreateUnavailability(ctx context.Context, entry *models.RoomUnavailability) error {
	return r.db.WithContext(ctx).Create(entry).Error
}
