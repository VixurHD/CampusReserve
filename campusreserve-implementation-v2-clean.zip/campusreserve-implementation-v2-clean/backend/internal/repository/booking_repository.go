package repository

import (
	"context"
	"time"

	"github.com/VixurHD/CampusReserve/backend/internal/models"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type BookingRepository struct {
	db *gorm.DB
}

func NewBookingRepository(db *gorm.DB) *BookingRepository {
	return &BookingRepository{db: db}
}

func (r *BookingRepository) RawDB() *gorm.DB {
	return r.db
}

func (r *BookingRepository) GetByID(ctx context.Context, bookingID uint64) (*models.Booking, error) {
	var booking models.Booking
	err := r.db.WithContext(ctx).
		Preload("Room").
		Preload("Room.Building").
		Preload("User").
		Preload("Approver").
		Preload("StatusHistory", func(db *gorm.DB) *gorm.DB {
			return db.Order("created_at ASC")
		}).
		First(&booking, bookingID).Error
	if err != nil {
		return nil, err
	}
	return &booking, nil
}

func (r *BookingRepository) GetByIDForUpdate(ctx context.Context, tx *gorm.DB, bookingID uint64) (*models.Booking, error) {
	var booking models.Booking
	err := tx.WithContext(ctx).
		Clauses(clause.Locking{Strength: "UPDATE"}).
		Preload("Room").
		First(&booking, bookingID).Error
	if err != nil {
		return nil, err
	}
	return &booking, nil
}

func (r *BookingRepository) ListByUser(ctx context.Context, userID uint64) ([]models.Booking, error) {
	var bookings []models.Booking
	err := r.db.WithContext(ctx).
		Preload("Room").
		Preload("Room.Building").
		Where("user_id = ?", userID).
		Order("starts_at DESC").
		Find(&bookings).Error
	return bookings, err
}

func (r *BookingRepository) ListByStatus(ctx context.Context, status models.BookingStatus) ([]models.Booking, error) {
	var bookings []models.Booking
	query := r.db.WithContext(ctx).
		Preload("Room").
		Preload("Room.Building").
		Preload("User").
		Order("starts_at ASC")
	if status != "" {
		query = query.Where("status = ?", status)
	}
	err := query.Find(&bookings).Error
	return bookings, err
}

func (r *BookingRepository) Save(ctx context.Context, tx *gorm.DB, booking *models.Booking) error {
	return tx.WithContext(ctx).Save(booking).Error
}

func (r *BookingRepository) HasApprovedConflict(ctx context.Context, tx *gorm.DB, roomID uint64, startsAt, endsAt time.Time, excludeBookingID *uint64) (bool, error) {
	query := tx.WithContext(ctx).
		Model(&models.Booking{}).
		Where("room_id = ? AND status = ? AND starts_at < ? AND ends_at > ?", roomID, models.BookingStatusApproved, endsAt, startsAt)
	if excludeBookingID != nil {
		query = query.Where("id <> ?", *excludeBookingID)
	}
	var count int64
	err := query.Count(&count).Error
	return count > 0, err
}

func (r *BookingRepository) HasUnavailabilityConflict(ctx context.Context, tx *gorm.DB, roomID uint64, startsAt, endsAt time.Time) (bool, error) {
	var count int64
	err := tx.WithContext(ctx).
		Model(&models.RoomUnavailability{}).
		Where("room_id = ? AND starts_at < ? AND ends_at > ?", roomID, endsAt, startsAt).
		Count(&count).Error
	return count > 0, err
}

func (r *BookingRepository) WithTransaction(ctx context.Context, fn func(tx *gorm.DB) error) error {
	return r.db.WithContext(ctx).Transaction(fn)
}
