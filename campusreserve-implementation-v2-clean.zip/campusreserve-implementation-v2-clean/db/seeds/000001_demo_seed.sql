BEGIN;

INSERT INTO users (full_name, email, role, group_name, department)
VALUES
    ('Admin Demo', 'admin@nstu.local', 'admin', NULL, 'CampusReserve'),
    ('Иван Петров', 'student1@nstu.local', 'student', 'ПМИ-31', NULL),
    ('Мария Смирнова', 'teacher1@nstu.local', 'teacher', NULL, 'Кафедра ИВТ')
ON CONFLICT (email) DO NOTHING;

INSERT INTO buildings (code, name, address, description)
VALUES
    ('7k', '7 корпус', 'г. Новосибирск, проспект Карла Маркса, 20', 'Пилотный корпус для первого этапа')
ON CONFLICT (code) DO NOTHING;

INSERT INTO equipment (code, name, description)
VALUES
    ('projector', 'Проектор', 'Базовый мультимедийный проектор'),
    ('board', 'Маркерная доска', 'Большая настенная доска'),
    ('pc', 'Компьютер', 'Преподавательский ПК')
ON CONFLICT (code) DO NOTHING;

INSERT INTO rooms (building_id, room_number, name, floor, capacity, room_type, description)
SELECT b.id, x.room_number, x.name, x.floor, x.capacity, x.room_type, x.description
FROM buildings b
JOIN (
    VALUES
        ('701', 'Лекционная аудитория 701', 7, 120, 'lecture', 'Подходит для больших лекций'),
        ('705', 'Практическая аудитория 705', 7, 36, 'practice', 'Для практических занятий и семинаров'),
        ('711', 'Лаборатория 711', 7, 24, 'lab', 'Компьютерная лаборатория')
) AS x(room_number, name, floor, capacity, room_type, description) ON TRUE
WHERE b.code = '7k'
ON CONFLICT (building_id, room_number) DO NOTHING;

INSERT INTO room_equipment (room_id, equipment_id, quantity)
SELECT r.id, e.id, x.quantity
FROM rooms r
JOIN buildings b ON b.id = r.building_id AND b.code = '7k'
JOIN (
    VALUES
        ('701', 'projector', 1),
        ('701', 'board', 1),
        ('705', 'board', 1),
        ('711', 'pc', 24),
        ('711', 'projector', 1)
) AS x(room_number, equipment_code, quantity) ON x.room_number = r.room_number
JOIN equipment e ON e.code = x.equipment_code
ON CONFLICT (room_id, equipment_id) DO NOTHING;

COMMIT;
